package relaxngcc.grammar;

/**
 * @author
 *      Kohsuke Kawaguchi (kk@kohsuke.org)
 */
public abstract class NameClass {
    public abstract Object apply(NameClassFunction f);
}
