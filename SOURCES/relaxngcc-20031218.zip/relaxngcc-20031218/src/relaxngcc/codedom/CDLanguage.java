package relaxngcc.codedom;

/**
 * @author Administrator
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class CDLanguage {
    public static final int JAVA = 0;
    //following languages will be supported later
    //public static final int CSHARP = 1;
    //public static final int RUBY = 2;
    //...
    
    //number of supported languages
    public static final int LANGUAGE_COUNT = 1;

}
